<?php include 'header.php'; ?>
	
	<div class="section">
		<div class="container">

			<h3 class="text-center">Kontak</h3>
			
			<div class="row">
				<div class="col-4">

					<p style="margin-bottom: 10px;"><b>Alamat : </b> <br> <?= $d->alamat ?></p>
					<p style="margin-bottom: 10px;"><b>Telepon : </b> <br> <?= $d->telepon ?></p>
					<p style="margin-bottom: 10px;"><b>Email : </b> <br> <?= $d->email ?></p>
					<p style="margin-bottom: 10px;"><b>Jam Kerja : </b> <br> Senin : 08.00-09.00 WIB<br> Selasa : 08.00-09.00 WIB<br> Rabu : 08.00-09.00 WIB<br> Kamis : 08.00-09.00 WIB<br> Jumat : 08.00-09.00 WIB<br> Sabtu : 08.00-09.00 WIB<br> Minggu : 08.00-09.00 WIB</br></p>
				

					<div class="box-gmaps" style="display: inline">
						<iframe src="<?= $d->google_maps ?>" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>


<?php include 'footer.php'; ?>