-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Agu 2023 pada 12.08
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sekolah.`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `galeri`
--

CREATE TABLE `galeri` (
  `id` int(11) NOT NULL,
  `foto` varchar(50) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `galeri`
--

INSERT INTO `galeri` (`id`, `foto`, `keterangan`, `created_at`, `updated_at`) VALUES
(3, 'galeri1688435139.jpeg', 'Ruang Kepala Kantor Notaris Lily Mardiah, S.H', '2022-09-18 07:22:07', '2023-07-04 08:50:17'),
(4, 'galeri1688435152.jpeg', 'Ruang Pembuatan Akta', '2023-07-04 01:45:52', '2023-07-04 08:49:47'),
(5, 'galeri1688435175.jpeg', 'Proses Penandatanganan Akta', '2023-07-04 01:46:15', '2023-07-04 08:49:17'),
(6, 'galeri1688435215.jpeg', 'Proses Akad Dengan Nasabah ', '2023-07-04 01:46:55', '2023-07-17 23:18:46'),
(7, 'galeri1688435300.jpeg', 'Ruang Depan Kantor Notaris', '2023-07-04 01:48:20', '2023-07-04 08:48:52'),
(8, 'galeri1688435470.jpeg', 'Foto Pegawai Dan Kepala Kantor Notaris Lily Mardia', '2023-07-04 01:51:10', '2023-07-04 08:51:55'),
(9, 'galeri1688435478.jpeg', 'Buka Puasa Bersama Pegawai Dan Kepala Kantor Notar', '2023-07-04 01:51:18', '2023-07-22 07:29:01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `informasi`
--

CREATE TABLE `informasi` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `informasi`
--

INSERT INTO `informasi` (`id`, `judul`, `keterangan`, `gambar`, `created_at`, `updated_at`, `created_by`) VALUES
(3, 'Rista Astina', '<p>Pegawai di Kantor Notaris Lily Mardiah, S.H yang bertugas untuk membuat akta.</p>', 'informasi1688430132.jpeg', '2022-09-05 04:54:16', '2023-07-04 07:22:12', 2),
(5, 'Aisyah Sianturi', '<p>Pegawai di Kantor Notaris Lily Mardiah, S.H yang bertugas sebagai pembuat laporan dan penerima tamu.</p>', 'informasi1688430557.jpeg', '2023-07-04 00:29:17', NULL, 12),
(6, 'Notaris Lily Mardiah, S.H', '<p>Ibu notaris di Kantor Notaris Lily Mardiah, S.H&nbsp;</p>', 'informasi1688433881.jpeg', '2023-07-04 00:30:52', '2023-07-04 08:24:41', 12);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`id`, `nama`, `keterangan`, `gambar`, `created_at`, `updated_at`) VALUES
(2, 'Akta Hibah', 'Akta Hibah adalah dokumen penting yang memiliki kekuatan hukum atas pemberian barang atau tanah kepada orang lain.\r\nPada umumnya penerima surat hibah wasiat adalah orang pribadi yang masih dalam hubungan keluarga dengan pemberi hibah wasiat, atau orang pribadi yang tidak mampu.', 'jurusan1689647828.jpeg', '2022-09-03 12:11:19', '2023-07-18 09:37:08'),
(3, 'Akta Jual Beli', 'Akta Jual Beli (AJB) biasanya ada saat melakukan transaksi jual beli properti.\r\nAJB merupakan dokumen otentik yang dibuat oleh Pejabat Pembuat Akta Tanah untuk peralihan hak atas tanah & bangunan.', 'jurusan1689647814.jpeg', '2022-09-06 03:30:26', '2023-07-18 09:36:54'),
(4, 'Surat Kuasa Membebankan Hak Tanggungan', 'Surat Kuasa Membebankan Hak Tanggungan (SKMHT) adalah kuasa yang bersifat khusus, tidak memuat kuasa untuk melakukan perbuatan melawan hukum lain selain membebankan hak tanggungan.\r\nSKMHT diberikan oleh pemberi jaminan kepada pihak lain (biasanya kepada bank) untuk membebankan hak tanggungan (menandatangani APHT)', 'jurusan1689647773.jpeg', '2022-09-06 03:31:27', '2023-07-18 09:36:13'),
(5, 'Akta Pemberian Hak Tanggungan', 'Akta Pemberian Hak Tanggungan (APHT) adalah berkas penting untuk mengatur ketentuan terkait pemberian hak tanggungan oleh kreditur kepada peminjam dalam proses pengajuan KPR.\r\nHak tanggungan diberikan sebagai jaminan bagi debitur untuk melunasi hutangnya kepada kreditur sesuai dengan perjanjian yang telah dibuat.\r\n\r\nPersyaratan yang harus disiapkan yaitu:\r\n\r\n\r\n1. Fotokopi KTP\r\n\r\n2. NPWP\r\n\r\n3. Kartu Keluarga\r\n\r\n4. Surat Nikah\r\n\r\n5. Fotokopi PBB Terakhir\r\n\r\n6. Surat Kuasa Membebankan Hak Tanggungan (Jika menggunakan SKMHT)\r\n\r\n7. Anggaran Dasar beserta perubahan-perubahan dari perusahaan yang menjaminkan tanahnya. \r\n', 'jurusan1689972746.jpeg', '2022-09-06 03:32:25', '2023-07-24 10:39:48');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaturan`
--

CREATE TABLE `pengaturan` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  `alamat` text NOT NULL,
  `logo` varchar(50) NOT NULL,
  `favicon` varchar(50) NOT NULL,
  `tentang_sekolah` text NOT NULL,
  `foto_sekolah` varchar(50) NOT NULL,
  `google_maps` text NOT NULL,
  `nama_kepsek` varchar(50) NOT NULL,
  `foto_kepsek` varchar(50) NOT NULL,
  `sambutan_kepsek` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengaturan`
--

INSERT INTO `pengaturan` (`id`, `nama`, `email`, `telepon`, `alamat`, `logo`, `favicon`, `tentang_sekolah`, `foto_sekolah`, `google_maps`, `nama_kepsek`, `foto_kepsek`, `sambutan_kepsek`, `created_at`, `updated_at`) VALUES
(1, 'Kantor Notaris Lily Mardiah, S.H.', 'lilymardiahlubis@gmail.com', '0634-26287', 'Jl. P. Diponegoro No. 32 Kel. Wek II Kec. Padangsidimpuan Utara Kota Padangsidimpuan Sumatera Utara\r\nKode Pos : 79681', 'logo1688432765.jpg', 'logo1688432810.jpg', '<p>Selamat datang di website Kantor Notaris dan PPAT Lily Mardiah, S.H.</p>\r\n<p>&nbsp;</p>\r\n<p>Kantor Notaris Lily Mardiah, S.H didirikan pada bulan Januari tahun 2001 oleh Ibu Notaris Lily Mardiah, S.H dengan SK. Menteri Dalam Negeri dan Otonomi Daerah/Kepala Badan Pertahanan Nasional Nomor 31-XI-2000 Tanggal 06 Oktober 2000.</p>\r\n<p>&nbsp;</p>\r\n<p>Disini kami menyediakan persyaratan atas hal-hal yang terkait dengan pertanahan yaitu Akta Jual Beli, Hibah, Akta Pemberian Hak Tanggungan, Surat Kuasa Membebankan Hak Tanggungan.&nbsp;</p>\r\n<p>&nbsp;</p>', 'sekolah1689215354.jpeg', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.6604714674686!2d99.26551806913683!3d1.3803763584247108!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x302c1c85b51e44fb%3A0xfcb8a55e0a9e04af!2sWARKOP%20BAYO%20ANGIN!5e0!3m2!1sen!2sid!4v1688433325614!5m2!1sen!2sid\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\">', 'Lily Mardiah, S.H', 'kepsek1688434297.jpeg', '<p>Selamat Datang di Web Kantor Notaris Lily Mardiah, S.H&nbsp;</p>', '2022-09-05 05:10:11', '2023-07-21 20:38:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `id` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` enum('Super Admin','Admin') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`id`, `nama`, `username`, `password`, `level`, `created_at`, `updated_at`) VALUES
(1, 'Artika', 'artika', '4b49773c29adff41f2bfd2e175a051ed', 'Super Admin', '2022-09-02 15:47:21', '2023-07-04 11:09:51'),
(12, 'Riski', 'riski', 'e10adc3949ba59abbe56e057f20f883e', 'Admin', '2023-05-20 06:57:03', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(11) NOT NULL,
  `nm_admin` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_informasi`
--

CREATE TABLE `tb_informasi` (
  `id_informasi` int(11) NOT NULL,
  `judul_informasi` varchar(200) NOT NULL,
  `informasi_` text NOT NULL,
  `tgl_dibuat` date NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_jurusan`
--

CREATE TABLE `tb_jurusan` (
  `id_jurusan` int(11) NOT NULL,
  `nm_jurusan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_profil_sekolah`
--

CREATE TABLE `tb_profil_sekolah` (
  `id_psekolah` int(11) NOT NULL,
  `profil_sekolah` text NOT NULL,
  `alamat_sekolah` varchar(100) NOT NULL,
  `hp_sekolah` varchar(20) NOT NULL,
  `email_sekolah` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `informasi`
--
ALTER TABLE `informasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pengaturan`
--
ALTER TABLE `pengaturan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `tb_informasi`
--
ALTER TABLE `tb_informasi`
  ADD PRIMARY KEY (`id_informasi`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indeks untuk tabel `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indeks untuk tabel `tb_profil_sekolah`
--
ALTER TABLE `tb_profil_sekolah`
  ADD PRIMARY KEY (`id_psekolah`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `informasi`
--
ALTER TABLE `informasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `pengaturan`
--
ALTER TABLE `pengaturan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_informasi`
--
ALTER TABLE `tb_informasi`
  MODIFY `id_informasi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  MODIFY `id_jurusan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_profil_sekolah`
--
ALTER TABLE `tb_profil_sekolah`
  MODIFY `id_psekolah` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
