<!-- footer -->
	<div class="footer">
		<div class="container text-center">
			Copyright &copy; 2023 - <?= $d->nama ?>.
		</div>
	</div>

</body>
</html>