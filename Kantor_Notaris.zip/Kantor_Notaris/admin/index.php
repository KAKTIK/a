
<?php include 'header.php' ?>

	<!-- content -->
	<div class="content">
		<div class="container">

			<div class="box">
				
				<div class="box-header">
					Dashboard
				</div>
				<div class="box-body">
					<h3>Selamat Datang <?= $_SESSION['uname'] ?> di Panel Admin <?= $d->nama ?></h3>
				</div>

			</div>
			<img src="../uploads/identitas/sekolah1689215354.jpeg" class="img-fluid box-body" alt="...">

		</div>
	</div>

<?php include 'footer.php' ?>