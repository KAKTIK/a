<?php 
	$conn = mysqli_connect('localhost', 'root', '', 'db_sekolah.') or die('Gagal Terhubung Ke Database');

 ?>
   
   