<?php include 'header.php'; ?>
	
	<div class="section">
		<div class="container">

			<h3 class="text-center">Tentang Kantor</h3>
			<img src="uploads/identitas/<?= $d->foto_sekolah ?>" width="26%" class="image">
			<?= $d->tentang_sekolah ?>
		</div>
	</div>

<?php include 'footer.php'; ?>